
/****************************************
**  名称：CH375或CH376操作CH341
**  描述：全速USB2.0主机例程，适应于CH375&CH376（只需要修改对应头文件）
****************************************
*/


#include "ch375.h"
#include "main.h"
#include "upscom.h"
#include "stdbool.h"
#include "usart.h"

#include "FreeRTOS.h"
#include "task.h"


#define	TRUE	1
#define	FALSE	0

#define	MAXSETUPPACK	8
uint8_t ucFlag_RxSuccece = 1;					// 正常接收UPS响应
uint8_t ucMax_package;
uint8_t ucConfigvalue;   //配置值
uint8_t ucBulkout_num,ucBulkin_num,ucIntin_num;

uint8_t ucaReq_buf[8];        					//请求包结构

uint8_t ucaDataBuf[128];							//usb输出缓冲区
uint8_t ucEndp6_mode=0x80, ucEndp7_mode=0x80;		//同步标志位初值

DEVICE_INFO   USBD;

extern volatile uint16_t g_usIoStatus;

// ms延时
void ch375_delayms( uint16_t delay )
{
    vTaskDelay(delay); 
}

void USB_Host_Init(void)
{
	uint8_t	Read_Data=0;
	/***** 硬件复位 *****/
	CH375_RST_0;
	ch375_delayms(50);
	CH375_WR_CMD_PORT( CMD_RESET_ALL );
	ch375_delayms(50);
	
	Read_Data = CH375_read_id();
//	printf("chip-id:0x%02x \r\n",Read_Data);
	CH375_set_usb_mode( 5 );  /* 设置USB主机模式, 如果设备端是CH37X, 那么5和6均可 */
//	printf("wait connect... \r\n");
	ch375_delayms(100);/* 有些USB设备要等待数百毫秒才能正常工作 */
}

uint8_t USB_init(void)		// 并口方式
{
	uint8_t s;
	uint16_t len;	

	ucMax_package = MAXSETUPPACK;

    /***** 获取USB设备速度  *****/	
	s = CH375_Get_freq();	
//	printf("speed:0x%x \r\n",(uint16_t)s);
	/***** 复位USB  *****/	
	CH375_set_usb_mode( 7 );				/* 总线复位 */
	ch375_delayms(30);
	CH375_set_usb_mode( 6 );		
	if( s&0x10 )	CH375_Set_freq();		/* 切换使375B进入低速模式 */
	ch375_delayms(100);
	
	/***** 获取设备描述符 *****/
	CH375_get_descr(0x01);//获取设备描述符
	ucMax_package = ucaDataBuf[7];  //端点0最大包大小

	/***** 设置地址  *****/
	s=CH375_Set_addr(1);//设置地址			
//    printf("SetAddr:0x%02x \r\n",s);

	/***** 获取配置描述符 *****/
	ucaReq_buf[0]=0x80;ucaReq_buf[1]=0x06;ucaReq_buf[2]=0x00;ucaReq_buf[3]=0x02;
	ucaReq_buf[4]=0x00;ucaReq_buf[5]=0x00;ucaReq_buf[6]=0x04;ucaReq_buf[7]=0x00;
	//================================
	s = CH375_SETUP_Transfer(ucaDataBuf, &len);
	if(s != USB_INT_SUCCESS)
	{
//        printf("set  fail1 \r\n");
		return 2;
	}
	ucaReq_buf[6] = ucaDataBuf[2];
	ucaReq_buf[7] = ucaDataBuf[3];
	//================================
	s = CH375_SETUP_Transfer(ucaDataBuf, &len);
	if(s != USB_INT_SUCCESS)
	{
//        printf("set  fail2 \r\n");
		return 2;
	}
    
//	for ( i_uinit=0; i_uinit!=len; i_uinit++ ) printf( "%02x ", (uint32_t)ucaDataBuf[i_uinit] );
//		printf( "\r\n" );
	/*****分析描述符 ***/
	CH375_parse_config_descr(ucaDataBuf);			//保存描述符中一些值
	/***** 设置配置 *****/
//	printf("set config \r\n");	
	s = CH375_set_config(ucConfigvalue);  // 设置设备端的USB配置
	if(s != USB_INT_SUCCESS)
	{	
//        printf("set config failed \r\n");
        return 2;
	}

/***** 类命令:配置341 9600波特率，8位数据位，无校验 *****/
	s = CH34X_Baud_Config(9600);
	if(s != USB_INT_SUCCESS)
	{	
//        printf("set baud failed \r\n");
        return 2;
	}

	// 设置重试次数-不重试，NAK状态返回
	CH375_Set_Retry( 0x00 );
	ucEndp6_mode = ucEndp7_mode=0x80;			//DATA0发送器
	
	USBD.status = USBD_READY;   //USB准备完成

	return 0;
}

uint16_t CH375_SETUP_Transfer( uint8_t *ucaDataBuf, uint16_t *plen)
{	
	uint8_t  l, s;
	uint16_t req_len, real_len = 0;
	uint8_t *p = ucaDataBuf;
	ucEndp7_mode=0x80;	//DATA0发送器
	ucEndp6_mode=0xc0;	//DATA1接收器
	req_len = (uint16_t)(ucaReq_buf[7]<<8)|ucaReq_buf[6];
	
/* SETUP阶段 */	
	CH375_wr_usb_data(8, ucaReq_buf);	
	CH375_toggle_send();
	s = CH375_issue_token(0,DEF_USB_PID_SETUP );
	if(s != USB_INT_SUCCESS)		
	{	
		return(0);
	}
	
/* DATA阶段 */	
	delay1us(2);
	if(ucaReq_buf[0]&0x80)		//IN数据
	{
		while(req_len)
		{		
			CH375_toggle_recv();
			s = CH375_issue_token(0 , DEF_USB_PID_IN);
			if( s == USB_INT_SUCCESS )
			{
				l = CH375_rd_usb_data( p );
				real_len += l;
				if( l<ucMax_package )		//短包
				{
					break;
				}
				p += l;
				req_len -= l;
			}
			else return(0);
		}	
	}
	else							//OUT数据
	{
		while(req_len)
		{		
			l = (req_len>ucMax_package)?ucMax_package:req_len;
			CH375_wr_usb_data(l, p);
			CH375_toggle_send();			
			s = CH375_issue_token(0 , DEF_USB_PID_OUT);
			if( s == USB_INT_SUCCESS )
			{
				real_len += l;
				p += l;
				req_len -= l;
			}
			else return(0);
		}
	}
/* 状态阶段 */
	ucEndp7_mode = ucEndp6_mode = 0xc0;	//DATA1
	if(ucaReq_buf[0]&0x80)		
	{
		CH375_wr_usb_data(0, ucaReq_buf);
		CH375_toggle_send();
		s = CH375_issue_token(0, DEF_USB_PID_OUT);
	}
	else
	{
		CH375_toggle_recv();
		s = CH375_issue_token(0 , DEF_USB_PID_IN);
	}
	if(s != USB_INT_SUCCESS)
	{
		return(0);
	}

	*plen = real_len;
	
	return(s);		//成功
}


uint8_t CH375_set_usb_mode( uint8_t mode ) {  // 设置CH37x工作模式
	CH375_WR_CMD_PORT( CMD_SET_USB_MODE );
	CH375_WR_DAT_PORT( mode );
	delay1us(25);
	if ( CH375_RD_DAT_PORT()==CMD_RET_SUCCESS ) return( TRUE );  /* 成功 */
	return( FALSE );  /* CH375出错,例如芯片型号错或者处于串口方式或者不支持 */
}

uint8_t CH375_Get_freq(void)
{		
	CH375_WR_CMD_PORT(0x0a);    // 查询当前设备速度
	CH375_WR_DAT_PORT(0x07);	
	return (CH375_RD_DAT_PORT());
}

void CH375_Set_freq(void)
{	
	CH375_WR_CMD_PORT(0x0b);    // 切换是375B进入低速模式
	CH375_WR_DAT_PORT(0x17);
	CH375_WR_DAT_PORT(0xd8);
}

uint8_t CH375_set_config( uint8_t cfg ) {		// 设置设备端的USB配置
	CH375_WR_CMD_PORT( CMD_SET_CONFIG );			// 设置设备端的USB配置
	CH375_WR_DAT_PORT( cfg );						// 此值取自USB设备的配置描述符中
	return( CH375_wait_interrupt() );						// 等待CH375操作完成
}

void CH375_parse_config_descr(uint8_t *p)
{
	uint8_t i,l;
	
	ucConfigvalue = p[5];								// 保存配置值
	
	for(i=0;i<p[2];i+=l)
	{				
		if((p[i]==0x07)&&(p[i+1]==0x05))			//端点描述符 ucBulkout_num
		{	
			if((p[i+2]&0x80)&&((p[i+3])==0x02))		//批量IN端点
			{
				ucBulkin_num = p[i+2]&0x0f;
			}
			if((!(p[i+2]&0x80))&&((p[i+3])==0x02))	//批量OUT端点
				ucBulkout_num = p[i+2]&0x0f;
			if((p[i+2]&0x80)&&((p[i+3])==0x03))		//中断IN端点
				ucIntin_num = p[i+2]&0x0f;
		}
		l=p[i];
	}
}
uint8_t CH375_Set_addr( uint8_t addr ) {		// 设置设备端的USB地址
	uint8_t s;
	
	CH375_WR_CMD_PORT( CMD_SET_ADDRESS );			// 设置USB设备端的USB地址
	CH375_WR_DAT_PORT( addr );  					// 地址, 从1到127之间的任意值, 常用2到20
	s = CH375_wait_interrupt();  							// 等待CH375操作完成
	if ( s == USB_INT_SUCCESS ) { 					// 操作成功
		CH375_WR_CMD_PORT( CMD_SET_USB_ADDR );  	// 设置USB主机端的USB地址
		CH375_WR_DAT_PORT( addr );					// 当目标USB设备的地址成功修改后,应该同步修改主机端的USB地址
	}
	return( s );
}
// 使用获取描述符命令,参数1获取设备描述符，参数2获取配置描述符
// 因为内部缓冲区只有64字节，所以如果设备描述符超过64字节，可能或发生溢出错误，所以本例程未使用此方式
uint8_t CH375_get_descr( uint8_t type ) {		// 从设备端获取描述符
	uint8_t status;
    uint8_t i, len;
	CH375_WR_CMD_PORT( CMD_GET_DESCR );
	CH375_WR_DAT_PORT( type );  /* 描述符类型, 只支持1(设备)或者2(配置) */
	status=CH375_wait_interrupt();  /* 等待CH375操作完成 */
	if ( status==USB_INT_SUCCESS ) 
     {  /* 操作成功 */
		len=CH375_rd_usb_data( ucaDataBuf );
//		for ( i=0; i!=len; i++ ) printf( "%02x ", (uint32_t)ucaDataBuf[i] );
//		printf( "\r\n" );
	}
	return( status );
}
//配置341波特率 ,成功返回USB_INT_SUCCESS
uint8_t CH34X_Baud_Config(uint32_t baud)
{
	uint8_t s=0;
	uint8_t divisor = 0; 
	uint8_t factor = 0;
	uint8_t reg_value=0;
	uint32_t tmp;
	
	reg_value|=0x03;           //数据位8位
	tmp=(1532620800/baud);
	divisor=3; 
	while((tmp>0xfff0)&&divisor){
		tmp>>=3;
		divisor --;
	}	
	if(tmp>0xfff0)
		return 0xFE;	
	tmp=0x10000-tmp;                    
	tmp=(tmp&0xff00)>>8;                   
	factor=tmp;
	reg_value|=0xc0; 
	
	ucaReq_buf[0]=0x40;ucaReq_buf[1]=0xa1;ucaReq_buf[2]=0x9c;ucaReq_buf[3]=reg_value;
	ucaReq_buf[4]=0x80|divisor;ucaReq_buf[5]=factor;ucaReq_buf[6]=0x00;ucaReq_buf[7]=0x00;
	s = CH375_SETUP_Transfer(NULL, NULL);
	return( s );		
}

uint8_t CH375_read_id(void)
{
	CH375_WR_CMD_PORT( CMD_GET_IC_VER );
	return (CH375_RD_DAT_PORT());
}



uint8_t USB_send_data(uint8_t *pData, uint8_t ucDataLen)
{
	uint8_t s;

	CH375_wr_usb_data(ucDataLen, (uint8_t *)pData);
	CH375_toggle_send();		
	s = CH375_issue_token(ucBulkout_num , DEF_USB_PID_OUT);
	return s;	
}

uint16_t USB_recv_data(uint8_t *pData, uint16_t usWaitMs)
{
	uint8_t s;
	uint16_t usTotalLen = 0;
	uint16_t usErr = 0;

	while( usWaitMs-- )
	{
		CH375_WR_CMD_PORT( CMD_SET_ENDP6);	//设置接收同步标志
		CH375_WR_DAT_PORT( ucEndp6_mode );				
		s = CH375_issue_token(ucBulkin_num , DEF_USB_PID_IN);
		if(s != USB_INT_SUCCESS)
		{
			usErr++;
			ch375_delayms(1);
			continue;
		}
		usTotalLen += CH375_rd_usb_data( &pData[usTotalLen] );
		ucEndp6_mode ^= 0x40;	
	}

	return usTotalLen;	
}

	
/********************** 内部函数定义 *************************/

void	delay1us(uint16_t t )
{
	uint16_t i,j;
	for ( i = 0; i < t; i++ ) j++;
}

void CH375_WR_CMD_PORT( uint8_t cmd ) // 向CH375的命令端口写入命令,周期不小于4uS,如果单片机较快则延时
{  			
	delay1us(10);
	CH375_CS_0;
	CH375_A0_1;
	CH375_DATA(cmd);
	CH375_WR_0;
	delay1us(10);
	CH375_CS_1;
	CH375_WR_1;
	delay1us(200);
}

void CH375_WR_DAT_PORT( uint8_t dat )  // 向CH375的数据端口写入数据,周期不小于1.5uS,如果单片机较快则延时
{ 
	delay1us(10);
	CH375_CS_0;
	CH375_A0_0;
	CH375_DATA(dat);
	CH375_WR_0;
	delay1us(10);
	CH375_CS_1;
	CH375_WR_1;
	CH375_A0_1;
	delay1us(200);
}

uint8_t CH375_RD_DAT_PORT(void)  					// 从CH375的数据端口读出数据,周期不小于1.5uS,如果单片机较快则延时
{ 		
	uint8_t data;
	CH375_CS_0;
	CH375_A0_0;
	CH375_RD_0;
	CH375_DATA_INPUT();
	delay1us(10);
	data = CH375_DATA_PORT->IDR;
	delay1us(10);
	CH375_CS_1;
	CH375_A0_1;
	CH375_RD_1;
	CH375_DATA_OUTPUT();
	return data;
}

void CH375_wr_usb_data( uint8_t len, uint8_t *buf )// 向CH37X写入数据块 
{		
	CH375_WR_CMD_PORT( CMD_WR_USB_DATA7 );						// 向CH375的端点缓冲区写入准备发送的数据
	CH375_WR_DAT_PORT( len );									// 后续数据长度, len不能大于64
	while( len-- ) CH375_WR_DAT_PORT( *buf++ );
}

uint8_t CH375_rd_usb_data( uint8_t *buf ) // 从CH37X读出数据块
{				
	uint8_t i, len;
	
	CH375_WR_CMD_PORT( CMD_RD_USB_DATA );						// 从CH375的端点缓冲区读取接收到的数据
	len=CH375_RD_DAT_PORT();  									// 后续数据长度
	for ( i=0; i!=len; i++ )
	{
	    *buf++ = CH375_RD_DAT_PORT();
	}
	return( len );
}

/* 数据同步 */
/* USB的数据同步通过切换DATA0和DATA1实现: 在设备端, CH372/CH375可以自动切换;
   在主机端, 必须由SET_ENDP6和SET_ENDP7命令控制CH375切换DATA0与DATA1.
   主机端的程序处理方法是为SET_ENDP6和SET_ENDP7分别提供一个全局变量,
   初始值均为80H, 每执行一次成功事务后将位6取反, 每执行一次失败事务后将其复位为80H. */
void CH375_toggle_recv(void) // 主机发送成功后,切换DATA0和DATA1实现数据同步
{  
	CH375_WR_CMD_PORT( CMD_SET_ENDP6);
	CH375_WR_DAT_PORT( ucEndp6_mode );
	ucEndp6_mode^=0x40;
	delay1us(2);
}

void CH375_toggle_send(void) // 主机发送成功后,切换DATA0和DATA1实现数据同步
{  
	CH375_WR_CMD_PORT(CMD_SET_ENDP7);
	CH375_WR_DAT_PORT( ucEndp7_mode );
	ucEndp7_mode^=0x40;
	delay1us(2);
}

uint8_t CH375_issue_token( uint8_t endpnum, uint8_t pid ) // 执行USB事务
{  
	CH375_WR_CMD_PORT( CMD_ISSUE_TOKEN );
	CH375_WR_DAT_PORT( (endpnum<<4)|pid );  // 高4位目的端点号, 低4位令牌PID
	return (CH375_wait_interrupt());
}

uint8_t CH375_wait_interrupt(void) {  			// 主机端等待操作完成, 返回操作状态
	while( CH375_INT_WIRE );  				// 查询等待CH375操作完成中断(INT#低电平)
	CH375_WR_CMD_PORT( CMD_GET_STATUS );  	// 产生操作完成中断, 获取中断状态
	return( CH375_RD_DAT_PORT() );
}


/*USB 事务操作的重试次数*/
void CH375_Set_Retry(uint8_t num)
{
	CH375_WR_CMD_PORT( CMD_SET_RETRY);
	CH375_WR_DAT_PORT( 0x25);
	CH375_WR_DAT_PORT( num);
	delay1us(2);
}

uint8_t CH375_GetIntStatus( void )
{
	uint8_t res;
	CH375_WR_CMD_PORT( CMD_GET_STATUS );
	res = CH375_RD_DAT_PORT();
	return ( res );
}

void CH375_InitSysVar( void ) //初始化默认值
{
	memset(&USBD,0,sizeof(DEVICE_INFO));
	USBD.endp0_maxpack = 8;
	//USBD.status=0;
}

uint8_t CH375_DeviceConnect( void )  //检测连接
{
	uint8_t res;
	
	if( CH375_INT_WIRE == 0 ) CH375_GetIntStatus();
	CH375_WR_CMD_PORT( CMD_TEST_CONNECT );
	delay1us(5);
	res = CH375_RD_DAT_PORT();
	if( res == USB_INT_CONNECT || res == USB_INT_USB_READY )
		return ( TRUE );
	else 
		return ( FALSE );

		
}
uint8_t CH375_CheckConnect( void )           //检测是否有新设备连接
{
	if( CH375_DeviceConnect() )  
	{
		if( USBD.status == 0 )
			USBD.status = 1;         /* 刚连接，未初始化 */	
	}
	else
	{
		
		if( USBD.status > 0 )
			CH375_InitSysVar();                /* 设备拔出，恢复内部变量默认值 */
	}
	return ( USBD.status );
}



void CH375_Comm(void)
{
	uint8_t i = 0;
	uint8_t s = 0;
	uint8_t len = 0;
	uint8_t txBuf[8] ;
	// uint8_t txBuf[] = {0x1B, 0x00, 0x01, 0x00, 0x1C, 0x1D};
	uint8_t rxBuf[128];
	int err = 0;

	if(USBD.status == USBD_READY)		//确认是否连接
	{
		if(ucFlag_RxSuccece)
		{
			memset(rxBuf, 0, sizeof(rxBuf));
			if( ucUps_one )   //ups配置
			{
				for(i=0;i<8;i++)
						txBuf[i] = ucaUPS_AutoUP[i] ;
				ucFlag_GetUpsState=0;
			}
			else if(ucFlag_GetUpsState == 0)										// 获取UPS输入电压
			{
				for(i=0;i<8;i++)
					txBuf[i] = ucaUPS_GetInputVlt[i] ;
			}
			else if(ucFlag_GetUpsState == 1)								// 获取电池状态，2：休眠；3：浮充；4：均充；5：放电
			{
				for(i=0;i<8;i++)
					txBuf[i] = ucaUPS_GetBatMode[i] ;
			}
			else if(ucFlag_GetUpsState == 2)								// 获取UPS供电模式,0:不供电；1：旁路；2：主路；3：电池；5主路ECO
			{
				for(i=0;i<8;i++)
					txBuf[i] = ucaUPS_GetPwrMode[i] ;
			}
			else if(ucFlag_GetUpsState == 3)
			{
				if(ucUpsPwrMode == 2 && ucFlag_AllowUpsOff == 0)			// UPS处于主路供电
				{
					for(i=0;i<8;i++)
						txBuf[i] = ucaUPS_CancelPwroff[i] ;					// 取消UPS延时关机
				}
				else if(ucUpsPwrMode == 3 && ucFlag_AllowUpsOff == 1)		// UPS处于旁路供电
				{
					if( (g_usIoStatus&0x30)==0x30 && (g_usIoStatus&0xc0)==0xc0)		// PC和KUKA都处于关机模式
					{
						for(i=0;i<8;i++)
							txBuf[i] = ucaUPS_PwroffNow[i] ;					// 立即关闭UPS
					}
					else
					{
						for(i=0;i<8;i++)
							txBuf[i] = ucaUPS_DelayPwroff[i] ;				// 执行UPS延时关机
					}
				}
                else if(ucUpsPwrMode == 3 && ucFlag_AllowUpsOff == 0)		// UPS处于旁路供电
				{
					if( (g_usIoStatus&0x30)==0x30 && (g_usIoStatus&0xc0)==0xc0)			// PC和KUKA都处于关机模式
					{
						for(i=0;i<8;i++)
							txBuf[i] = ucaUPS_PwroffNow[i] ;					// 立即关闭UPS
					}
				}
				else
				{
					ucFlag_GetUpsState = 1 ;
					for(i=0;i<8;i++)
						txBuf[i] = ucaUPS_GetBatMode[i] ;
				}
			}
			
			CH375_wr_usb_data(sizeof(txBuf), (uint8_t *)txBuf);
			CH375_toggle_send();
			s = CH375_issue_token(ucBulkout_num , DEF_USB_PID_OUT);
			if(s != USB_INT_SUCCESS)
			{
				err++;
				if(err > 3)   				//连续出错3次，准备重新加载USB设备
				{
					USBD.status = USBD_UNCONNECT;
				}
			}
			ch375_delayms(300);  //该延时用来等待读取数据
			ucFlag_RxSuccece = 0;
		}
		
		len = USB_recv_data(rxBuf, 1);
		if(len != 0)
		{
			
			for(i=0;i<len;i++)
				ucaDMA_RxBuf[i] = rxBuf[i];
//			for(i=0;i<len;i++)
//				printf( "%c", ucaDMA_RxBuf[i] );
			
			ucDMA_RxLen = len;
			if(ucUps_one)
			{
			   ucUps_one=0;
			   ch375_delayms( 5000 ); //涉及到UPS的模式切换，必须延时后面的通信。不然UPS在切换模式的同时通信的数据会与现状不符合
			}
			
			Modbus_Analyze() ;	// 通讯接收数据分析
			ucFlag_RxSuccece = 1;
		}
	}
}

