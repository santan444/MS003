#ifndef __STMFLASH_H_
#define __STMFLASH_H_

#include <stdint.h>
						   
//////////////////////////////////////////////////////////////////////////////////////////////////////
//用户根据自己的需要设置
#define STM32_FLASH_SIZE 	256 	 		//所选STM32的FLASH容量大小(单位为K)
#define FLASH_WAITETIME  	50000          	//FLASH等待超时时间

#define FLASH_SAVE_ADDR  0X0803F800 		//最后一页 保存地址(必须为偶数，且其值要大于本代码所占用FLASH的大小+0X08000000)
#define FLASH_SAVE_ADDR2  0X0803F000 

//FLASH起始地址
#define STM32_FLASH_BASE 0x08000000 		//STM32 FLASH的起始地址

uint32_t STMFLASH_ReadWord(uint32_t faddr); //读字
void STMFLASH_Write_NoCheck(uint32_t WriteAddr,uint32_t *pBuffer,uint32_t NumToWrite);   
void STMFLASH_Write(uint32_t WriteAddr,uint32_t *pBuffer,uint32_t NumToWrite)	;		//从指定地址开始写入指定长度的数据
void STMFLASH_Read(uint32_t ReadAddr,uint32_t *pBuffer,uint32_t NumToRead)  ;   		//从指定地址开始读出指定长度的数据

uint16_t STMFLASH_ReadHalfWord(uint32_t faddr);
void STMFLASH_HalfWrite_NoCheck(uint32_t WriteAddr,uint16_t *pBuffer,uint32_t NumToWrite);   
void STMFLASH_HalfWrite(uint32_t WriteAddr,uint16_t *pBuffer,uint32_t NumToWrite)	;		//从指定地址开始写入指定长度的数据
void STMFLASH_HalfRead(uint32_t ReadAddr,uint16_t *pBuffer,uint32_t NumToRead) ;

#endif


