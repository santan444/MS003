#ifndef __UPSCOM_H_
#define __UPSCOM_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

#define MODBUS_RX_SIZE		255
#define MODBUS_TX_SIZE      255

//--------------- 以下为UPS配置CMD ---------------
extern uint8_t ucaUPS_GetInputVlt[] ;	// 获取UPS输入电压
extern uint8_t ucaUPS_GetBatMode[] ;	// 获取电池状态，2：休眠；3：浮充；4：均充；5：放电
extern uint8_t ucaUPS_GetPwrMode[] ;	// 获取UPS供电模式,0:不供电；1：旁路；2：主路；3：电池；5主路ECO
extern uint8_t ucaUPS_PwroffNow[] ;	// 执行UPS立马关机
extern uint8_t ucaUPS_DelayPwroff[] ;	// 执行UPS延时0.1min关机
extern uint8_t ucaUPS_CancelPwroff[];	// 取消UPS延时关机

extern uint8_t ucaUPS_AutoUP[8];	// 上市电自动开机

extern uint8_t ucUps_one;		// ups一次
extern uint8_t ucUpsPwrMode ;			// UPS供电模式
extern uint8_t ucUpsBatMode ;			// UPS电池模式
extern uint8_t ucFlag_AllowUpsOff ;	// 0:允许取消延时关机；1：允许执行延时关机
extern uint8_t ucFlag_AllowSendCmd ;	// 允许发送获取UPS状态指令,0：不允许；1：允许

extern uint8_t ucFlag_GetUpsState ;
extern uint8_t ucaDMA_RxBuf[MODBUS_RX_SIZE] ;			// 通讯DMA接收缓冲区
extern uint8_t ucDMA_RxLen  ;


void Modbus_Analyze(void) ;
void Do03Command(void) ;
void Do06Command(void) ;

#ifdef __cplusplus
}
#endif

#endif



