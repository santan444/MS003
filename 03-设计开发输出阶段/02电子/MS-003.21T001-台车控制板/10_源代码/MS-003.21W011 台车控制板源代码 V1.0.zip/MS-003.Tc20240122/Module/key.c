#include "key.h"  
#include "main.h"


/*static修饰静态全局变量，限制了其作用域，
即只在定义该变量的源文件内有效， 在同一源程序的其它源文件中不能使用它
*/
static uint8_t s_ucKeySta[] = {0, 0, 0, 0};

/*多个IO状态保存器
bit0,bit1: 第一个IO, 00 低电平,01 上升沿,10 下降沿,11 高电平.
bit2,bit3: 第二个IO, 00 低电平,01 上升沿,10 下降沿,11 高电平.
...
*/
volatile uint16_t   g_usIoStatus=0xff;

/**
	* @Function	    : IOScan
	* @Brief		: 按键状态扫描函数
	* @Input		: void
	* @Return		: void
	* @Others		: 放在定时器中断回调函数中调用
	*/
void IOScan(void)
{
    uint8_t i;
    static uint16_t s_usKeyBuff[] = {0xffff, 0xffff, 0xffff, 0xffff, 0xffff};
    
    ///注意此变量用static修饰，函数里面有一个static修饰的局部变量的时候，如果反复调用多次，
    //那么下一次函数用的该变量的值不会再被初始化一次了，而是采用上一次函数执行完之后此变量的值
    //读取按键值存入数组 
    s_usKeyBuff[0] = (s_usKeyBuff[0] << 1) | (KEY_PC_PWR & 0x0001);
    s_usKeyBuff[1] = (s_usKeyBuff[1] << 1) | (KEY_KUKA_PWR & 0x0001);
    s_usKeyBuff[2] = (s_usKeyBuff[2] << 1) | (LEVEL_PC & 0x0001);
    s_usKeyBuff[3] = (s_usKeyBuff[3] << 1) | (LEVEL_KUKA & 0x0001);
    
    for( i = 0; i < 4; i++ )
    {
        //忽略中间8位，只看前4位，后4位，即只看16位的 s_usKeyBuff & 0xf00f的结果
        //连续扫描16次,5ms*16=80ms，按键已松开(按下后再松开，即上升沿发生时)
        if( (0xf00f & s_usKeyBuff[i]) == 0x000f )           //上升沿
        {
            s_ucKeySta[i] = IO_UP;
        }
        else if( (0xf00f & s_usKeyBuff[i]) == 0xf000 )      //下降沿
        {
            s_ucKeySta[i] = IO_DOWN;
        }
        else if( ( 0xf00f & s_usKeyBuff[i]) == 0x0000)      //连续扫描16次都是0,10ms*16=160ms内都是按下状态，按键已按下
        {
            s_ucKeySta[i] = IO_DOWN_LEVEL;                  
        }        
        else if((0xf00f & s_usKeyBuff[i]) == 0xf00f)
        {
            s_ucKeySta[i] = IO_STATE_IDLE;
        }     
    }
}

/**
	* @Function	    : IOPress
	* @Brief		: 按键检测函数
	* @Input		: void
	* @Return		: uint8_t s_ucKey_Value
	* @Others		: 放在while(1)中调用
	*/
uint8_t IOPress(void)
{
    static uint8_t s_ucKey_Value = IO_STATE_IDLE;

	if(s_ucKeySta[0] == IO_DOWN_LEVEL)
	{
        s_ucKey_Value = g_usIoStatus&=0xfc;
	}
    else
    {
        s_ucKey_Value = g_usIoStatus|=0x03;	
    }
    
	if(s_ucKeySta[1] == IO_DOWN_LEVEL)
	{
		s_ucKey_Value = g_usIoStatus&=0xf3;
	}
    else
    {
        s_ucKey_Value = g_usIoStatus|=0x0c;	
    }  
    
    if(s_ucKeySta[2] == IO_DOWN_LEVEL)
	{
		s_ucKey_Value = g_usIoStatus&=0xcf;
	} 
    else
    {
        s_ucKey_Value = g_usIoStatus|=0x30;	
    }
    
    if(s_ucKeySta[3] == IO_DOWN_LEVEL)
	{
		s_ucKey_Value = g_usIoStatus&=0x3f;
	}
    else
    {
        s_ucKey_Value = g_usIoStatus|=0xc0;	
    }
    return s_ucKey_Value;
}

