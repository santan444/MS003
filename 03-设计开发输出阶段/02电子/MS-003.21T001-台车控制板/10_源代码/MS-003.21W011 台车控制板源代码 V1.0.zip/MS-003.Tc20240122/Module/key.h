#ifndef __KEY_H_
#define __KEY_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

extern volatile uint16_t g_usIoStatus;

void IOScan(void);  					//状态扫描函数
uint8_t IOPress(void);	 					//检测函数

#ifdef __cplusplus
}
#endif

#endif

