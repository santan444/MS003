/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    usart.h
  * @brief   This file contains all the function prototypes for
  *          the usart.c file
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USART_H__
#define __USART_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

extern UART_HandleTypeDef huart1;

/* USER CODE BEGIN Private defines */
//方式3 定义输出函数printf
//uint8_t u_buf[64];
//#define printf(...)  HAL_UART_Transmit_DMA((UART_HandleTypeDef * )&huart1, (uint8_t *)u_buf,\
											sprintf((char *)u_buf,__VA_ARGS__));

#define BUFFER_SIZE  64
//结构体类型定�?
typedef struct 
{
uint8_t _rxlen;  ////接收�?帧数据的长度
uint8_t _rxend;   //�?帧数据接收完成标�?
uint8_t _rxbufs[BUFFER_SIZE]; 	//接收数据
uint8_t _buf;	//接收中断缓冲
uint8_t _txbufs[BUFFER_SIZE]; 		//发�?�数�?	
}UART_DMA;

extern UART_DMA uart1; 
/* USER CODE END Private defines */

void MX_USART1_UART_Init(void);

/* USER CODE BEGIN Prototypes */
void DMA_IDE_Init(void);
/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __USART_H__ */

