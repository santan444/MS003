/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <stdarg.h>
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define DRILL_PWR_Pin GPIO_PIN_0
#define DRILL_PWR_GPIO_Port GPIOC
#define LEVEL_KUKA_Pin GPIO_PIN_1
#define LEVEL_KUKA_GPIO_Port GPIOC
#define LEVEL_PC_Pin GPIO_PIN_2
#define LEVEL_PC_GPIO_Port GPIOC
#define CH375_D0_Pin GPIO_PIN_0
#define CH375_D0_GPIO_Port GPIOA
#define CH375_D1_Pin GPIO_PIN_1
#define CH375_D1_GPIO_Port GPIOA
#define CH375_D2_Pin GPIO_PIN_2
#define CH375_D2_GPIO_Port GPIOA
#define CH375_D3_Pin GPIO_PIN_3
#define CH375_D3_GPIO_Port GPIOA
#define CH375_D4_Pin GPIO_PIN_4
#define CH375_D4_GPIO_Port GPIOA
#define CH375_D5_Pin GPIO_PIN_5
#define CH375_D5_GPIO_Port GPIOA
#define CH375_D6_Pin GPIO_PIN_6
#define CH375_D6_GPIO_Port GPIOA
#define CH375_D7_Pin GPIO_PIN_7
#define CH375_D7_GPIO_Port GPIOA
#define CH375_CS_Pin GPIO_PIN_4
#define CH375_CS_GPIO_Port GPIOC
#define CH375_A0_Pin GPIO_PIN_0
#define CH375_A0_GPIO_Port GPIOB
#define CH375_RD_Pin GPIO_PIN_1
#define CH375_RD_GPIO_Port GPIOB
#define CH375_WR_Pin GPIO_PIN_2
#define CH375_WR_GPIO_Port GPIOB
#define CH375_RST_Pin GPIO_PIN_10
#define CH375_RST_GPIO_Port GPIOB
#define CH375_INT_Pin GPIO_PIN_11
#define CH375_INT_GPIO_Port GPIOB
#define LED_RUN_Pin GPIO_PIN_15
#define LED_RUN_GPIO_Port GPIOA
#define KEY_PC_Pin GPIO_PIN_10
#define KEY_PC_GPIO_Port GPIOC
#define LED_PCPWR_Pin GPIO_PIN_11
#define LED_PCPWR_GPIO_Port GPIOC
#define KEY_KUKA_Pin GPIO_PIN_12
#define KEY_KUKA_GPIO_Port GPIOC
#define LED_KUKAPWR_Pin GPIO_PIN_2
#define LED_KUKAPWR_GPIO_Port GPIOD
#define KUKA_PWR_Pin GPIO_PIN_3
#define KUKA_PWR_GPIO_Port GPIOB
#define PC_PWR_Pin GPIO_PIN_4
#define PC_PWR_GPIO_Port GPIOB
#define LED_BAT_Pin GPIO_PIN_5
#define LED_BAT_GPIO_Port GPIOB
#define LED_220V_Pin GPIO_PIN_6
#define LED_220V_GPIO_Port GPIOB
#define LED_UPS_Pin GPIO_PIN_7
#define LED_UPS_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */
#define     LED_RunToggle   HAL_GPIO_TogglePin(LED_RUN_GPIO_Port, LED_RUN_Pin) //系统运行指示灯翻�?
#define     LED_RunOn       HAL_GPIO_WritePin(LED_RUN_GPIO_Port, LED_RUN_Pin,GPIO_PIN_RESET) 
#define     LED_RunOff      HAL_GPIO_WritePin(LED_RUN_GPIO_Port, LED_RUN_Pin,GPIO_PIN_SET) 

#define     LED_BAT_ON      HAL_GPIO_WritePin(LED_BAT_GPIO_Port, LED_BAT_Pin,GPIO_PIN_SET) //
#define     LED_BAT_OFF     HAL_GPIO_WritePin(LED_BAT_GPIO_Port, LED_BAT_Pin,GPIO_PIN_RESET) 
#define     LED_220V_ON     HAL_GPIO_WritePin(LED_220V_GPIO_Port, LED_220V_Pin,GPIO_PIN_SET) 
#define     LED_220V_OFF    HAL_GPIO_WritePin(LED_220V_GPIO_Port, LED_220V_Pin,GPIO_PIN_RESET) 
#define     LED_UPS_ON      HAL_GPIO_WritePin(LED_UPS_GPIO_Port, LED_UPS_Pin,GPIO_PIN_SET) 
#define     LED_UPS_OFF     HAL_GPIO_WritePin(LED_UPS_GPIO_Port, LED_UPS_Pin,GPIO_PIN_RESET) 

#define     LED_PcPwr_ON    HAL_GPIO_WritePin(LED_PCPWR_GPIO_Port, LED_PCPWR_Pin,GPIO_PIN_SET) // pc按键灯开
#define     LED_PcPwr_OFF   HAL_GPIO_WritePin(LED_PCPWR_GPIO_Port, LED_PCPWR_Pin,GPIO_PIN_RESET) 
#define     LED_KukaPwr_ON  HAL_GPIO_WritePin(LED_KUKAPWR_GPIO_Port, LED_KUKAPWR_Pin,GPIO_PIN_SET) // kuka按键灯开
#define     LED_KukaPwr_OFF HAL_GPIO_WritePin(LED_KUKAPWR_GPIO_Port, LED_KUKAPWR_Pin,GPIO_PIN_RESET) 

#define     PC_ON           HAL_GPIO_WritePin(PC_PWR_GPIO_Port, PC_PWR_Pin,GPIO_PIN_SET) //pc电源�?
#define     PC_OFF          HAL_GPIO_WritePin(PC_PWR_GPIO_Port, PC_PWR_Pin,GPIO_PIN_RESET) 
#define     KUKA_ON         HAL_GPIO_WritePin(KUKA_PWR_GPIO_Port, KUKA_PWR_Pin,GPIO_PIN_SET) //kuka电源�?
#define     KUKA_OFF        HAL_GPIO_WritePin(KUKA_PWR_GPIO_Port, KUKA_PWR_Pin,GPIO_PIN_RESET) 
#define     DRILL_ON        HAL_GPIO_WritePin(DRILL_PWR_GPIO_Port, DRILL_PWR_Pin,GPIO_PIN_SET)	    // 骨钻断电
#define     DRILL_OFF       HAL_GPIO_WritePin(DRILL_PWR_GPIO_Port, DRILL_PWR_Pin,GPIO_PIN_RESET) 	// 骨钻通电

//读取按键的电平状�?
#define KEY_PC_PWR         HAL_GPIO_ReadPin(KEY_PC_GPIO_Port, KEY_PC_Pin )            //读取PC按键信号
#define KEY_KUKA_PWR       HAL_GPIO_ReadPin(KEY_KUKA_GPIO_Port, KEY_KUKA_Pin )            //读取KUKA按键信号
#define LEVEL_PC           HAL_GPIO_ReadPin(LEVEL_PC_GPIO_Port, LEVEL_PC_Pin )            //读取PC�?机信�?
#define LEVEL_KUKA         HAL_GPIO_ReadPin(LEVEL_KUKA_GPIO_Port, LEVEL_KUKA_Pin )            //读取KUKA�?机信�?

//定义按键按下的标志位 
#define IO_STATE_IDLE 	    0			//处于空闲状�?�，此程序为高电平（无效状�?�）
#define IO_UP				1			//处于上升沿状态，
#define IO_DOWN 			2			//处于下降沿状态，
#define	IO_DOWN_LEVEL	    3			//处于低电平状态，

//ch375b引脚配置
#define CH375_INT_WIRE		(HAL_GPIO_ReadPin(CH375_INT_GPIO_Port, CH375_INT_Pin))// 连接CH375的INT#引脚，用于查询中断状�?

#define CH375_DATA_PORT      GPIOA
#define CH375_DATA_OUTPUT()		CH375_DATA_PORT->CRL = 0x33333333;
#define CH375_DATA_INPUT()		CH375_DATA_PORT->CRL = 0x88888888;
#define CH375_DATA(x)        {CH375_DATA_PORT->ODR &= 0xFF00;CH375_DATA_PORT->ODR |= x&0xFF;}

#define CH375_CS_1           CH375_CS_GPIO_Port->ODR |=  CH375_CS_Pin
#define CH375_CS_0           CH375_CS_GPIO_Port->ODR &= ~CH375_CS_Pin
#define CH375_A0_1           CH375_A0_GPIO_Port->ODR |=  CH375_A0_Pin
#define CH375_A0_0           CH375_A0_GPIO_Port->ODR &= ~CH375_A0_Pin
#define CH375_RD_1           CH375_RD_GPIO_Port->ODR |=  CH375_RD_Pin
#define CH375_RD_0           CH375_RD_GPIO_Port->ODR &= ~CH375_RD_Pin
#define CH375_WR_1           CH375_WR_GPIO_Port->ODR |=  CH375_WR_Pin
#define CH375_WR_0           CH375_WR_GPIO_Port->ODR &= ~CH375_WR_Pin
#define CH375_RST_1			 CH375_RST_GPIO_Port->ODR |=  CH375_RST_Pin		// 复位使能
#define CH375_RST_0          CH375_RST_GPIO_Port->ODR &= ~CH375_RST_Pin


void UART_IDLE_Callback(UART_HandleTypeDef *huart);
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
