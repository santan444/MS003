/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * File Name          : freertos.c
 * Description        : Code for freertos applications
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2023 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "main.h"
// #include "cmsis_os.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
// #include "gpio.h"

#include "key.h"
#include "stmflash.h"
#include "ch375.h"
#include "upscom.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
extern DMA_HandleTypeDef hdma_usart1_rx;
extern DMA_HandleTypeDef hdma_usart1_tx;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* 消息队列句柄 */
QueueHandle_t g_xUart1QueueHandle = NULL;    // 用于传输串口1接收的数
QueueHandle_t g_xUart1lenQueueHandle = NULL; // 用于传输串口1接收的数据长
QueueHandle_t g_xUpsQueueHandle = NULL;      // 用于传输UPS状态的数据

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
/* 串口命令列表 */
const uint8_t uuaPrivateCommandTable[22][5] =
    {
        {0x3C, 0x01, 0x01, 0x00, 0x3D}, // 程序更新
        {0x3C, 0x02, 0x01, 0x00, 0x3D}, // COM_OK!
        {0x3C, 0x03, 0x01, 0x00, 0x3D}, // 读软件版
        {0x3C, 0x04, 0x01, 0x00, 0x3D}, // 写软件版
        {0x3C, 0x05, 0x01, 0x00, 0x3D}, // 台车升
        {0x3C, 0x06, 0x01, 0x00, 0x3D}, // 升停止
        {0x3C, 0x07, 0x01, 0x00, 0x3D}, // 台车降
        {0x3C, 0x08, 0x01, 0x00, 0x3D}, // 降停止
        {0x3C, 0x09, 0x01, 0x00, 0x3D}, // 清ADX
        {0x3C, 0x0A, 0x01, 0x00, 0x3D}, // 读FLASH，配置偏移

        {0x3C, 0x0B, 0x01, 0x00, 0x3D}, // 读角度，写FLASH
        {0x3C, 0x0C, 0x01, 0x00, 0x3D}, // 只读角度
        {0x3C, 0x0D, 0x01, 0x00, 0x3D}, // 上平衡
        {0x3C, 0x0E, 0x01, 0x00, 0x3D}, // 下平衡
        {0x3C, 0x0F, 0x01, 0x00, 0x3D}, // M1上升点动
        {0x3C, 0x10, 0x01, 0x00, 0x3D}, // M1下降点动
        {0x3C, 0x11, 0x01, 0x00, 0x3D}, // M2上升点动
        {0x3C, 0x12, 0x01, 0x00, 0x3D}, // M2下降点动
        {0x3C, 0x13, 0x01, 0x00, 0x3D}, // M3上升点动
        {0x3C, 0x14, 0x01, 0x00, 0x3D}, // M3下降点动

        {0x3C, 0x15, 0x01, 0x00, 0x3D}, // M4上升点动
        {0x3C, 0x16, 0x01, 0x00, 0x3D}  // M4下降点动
};
/* 串口命令列表 */
const uint8_t ucaUartCommandTable[12][6] =
    {
        {0x1B, 0x10, 0x01, 0x00, 0x2C, 0x1D}, // 骨钻电源开
        {0x1B, 0x11, 0x01, 0x00, 0x2D, 0x1D}, // 骨钻电源关
        {0x1B, 0x12, 0x01, 0x00, 0x2E, 0x1D}, // 机械臂保护性停止
        {0x1B, 0x13, 0x01, 0x00, 0x2F, 0x1D}, // 机械臂解除保护性停止
        {0x1B, 0x14, 0x01, 0x00, 0x30, 0x1D}, // 机械臂正在运动
        {0x1B, 0x15, 0x01, 0x00, 0x31, 0x1D}, // 机械臂停止运动
        {0x1B, 0x16, 0x01, 0x00, 0x32, 0x1D}, // 脚撑正在运动
        {0x1B, 0x17, 0x01, 0x00, 0x33, 0x1D}, // 脚撑停止运动
        {0x1B, 0x18, 0x01, 0x00, 0x34, 0x1D}, // 脚撑上升到最顶
        {0x1B, 0x19, 0x01, 0x00, 0x35, 0x1D}, // 脚撑降低到最底

        {0x1B, 0x1A, 0x01, 0x00, 0x36, 0x1D}, // 台车控制板寻找指令
        {0x1B, 0x1B, 0x01, 0x00, 0x37, 0x1D}  // 升降控制板寻找指令
};

uint8_t ucaSoftVison[16] = {"V1.0 20240122"}; // 程序修改日期
extern volatile uint32_t CPU_RunTime;         /* 在高精度定时器中断中累加 */
/* USER CODE END Variables */
osThreadId LedRunHandle;
osThreadId KeyHandle;
osThreadId CPUHandle;
osThreadId UsbControlHandle;
osThreadId UartHandle;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */
void Jump_To_APP(void);
/* USER CODE END FunctionPrototypes */

void vLedRunTask(void const *argument);
void vKeyTask(void const *argument);
void vCPU_Task(void const *argument);
void vUsbControlTask(void const *argument);
void vUartTask(void const *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* GetIdleTaskMemory prototype (linked to static allocation support) */
void vApplicationGetIdleTaskMemory(StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize);

/* Hook prototypes */
void configureTimerForRunTimeStats(void);
unsigned long getRunTimeCounterValue(void);

/* USER CODE BEGIN 1 */
/* Functions needed when configGENERATE_RUN_TIME_STATS is on */
__weak void configureTimerForRunTimeStats(void)
{
    CPU_RunTime = 0UL;
}

__weak unsigned long getRunTimeCounterValue(void)
{
    return CPU_RunTime;
}
/* USER CODE END 1 */

/* USER CODE BEGIN GET_IDLE_TASK_MEMORY */
static StaticTask_t xIdleTaskTCBBuffer;
static StackType_t xIdleStack[configMINIMAL_STACK_SIZE];

void vApplicationGetIdleTaskMemory(StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize)
{
    *ppxIdleTaskTCBBuffer = &xIdleTaskTCBBuffer;
    *ppxIdleTaskStackBuffer = &xIdleStack[0];
    *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
    /* place for user code */
}
/* USER CODE END GET_IDLE_TASK_MEMORY */

/**
 * @brief  FreeRTOS initialization
 * @param  None
 * @retval None
 */
void MX_FREERTOS_Init(void)
{
    /* USER CODE BEGIN Init */

    /* USER CODE END Init */

    /* USER CODE BEGIN RTOS_MUTEX */
    /* add mutexes, ... */
    /* USER CODE END RTOS_MUTEX */

    /* USER CODE BEGIN RTOS_SEMAPHORES */
    /* add semaphores, ... */
    /* USER CODE END RTOS_SEMAPHORES */

    /* USER CODE BEGIN RTOS_TIMERS */
    /* start timers, add new ones, ... */
    /* USER CODE END RTOS_TIMERS */

    /* USER CODE BEGIN RTOS_QUEUES */
    /* add queues, ... */
    /* USER CODE END RTOS_QUEUES */

    /* Create the thread(s) */
    /* definition and creation of LedRun */
    osThreadDef(LedRun, vLedRunTask, osPriorityIdle, 0, 128);
    LedRunHandle = osThreadCreate(osThread(LedRun), NULL);

    /* definition and creation of Key */
    osThreadDef(Key, vKeyTask, osPriorityLow, 0, 128);
    KeyHandle = osThreadCreate(osThread(Key), NULL);

    /* definition and creation of CPU */
    //  osThreadDef(CPU, vCPU_Task, osPriorityHigh, 0, 512);
    //  CPUHandle = osThreadCreate(osThread(CPU), NULL);

    /* definition and creation of UsbControl */
    osThreadDef(UsbControl, vUsbControlTask, osPriorityNormal, 0, 256);
    UsbControlHandle = osThreadCreate(osThread(UsbControl), NULL);

    /* definition and creation of Uart */
    osThreadDef(Uart, vUartTask, osPriorityBelowNormal, 0, 256);
    UartHandle = osThreadCreate(osThread(Uart), NULL);

    /* USER CODE BEGIN RTOS_THREADS */
    /* add threads, ... */
    /* USER CODE END RTOS_THREADS */
}

/* USER CODE BEGIN Header_vLedRunTask */
/**
 * @brief  Function implementing the LedRun thread.
 * @param  argument: Not used
 * @retval None
 */
/* USER CODE END Header_vLedRunTask */
void vLedRunTask(void const *argument)
{
    /* USER CODE BEGIN vLedRunTask */
    UBaseType_t uxRxUpsLen = 0;
    uint8_t ucaRxUpsSte[2];
    /* Infinite loop */
    for (;;)
    {
        osDelay(1000);
        LED_RunToggle;

        uxRxUpsLen = uxQueueMessagesWaiting(g_xUpsQueueHandle); // 查询队列中当前的项目
        if (uxRxUpsLen != 0)
        {
            xQueueReceive(g_xUpsQueueHandle, ucaRxUpsSte, 0);
            if ((ucaRxUpsSte[0] == 3) || (ucaRxUpsSte[0] == 4)) // 浮充或均充
            {
                LED_BAT_ON;
            }
            else
            {
                LED_BAT_OFF;
            }
            if (ucaRxUpsSte[1] == 3) // 电池供电
            {
                LED_220V_OFF;
                LED_UPS_ON;
            }
            else
            {
                LED_220V_ON;
                LED_UPS_OFF;
            }
        }
    }
    /* USER CODE END vLedRunTask */
}

/* USER CODE BEGIN Header_vKeyTask */
/**
 * @brief Function implementing the Key thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_vKeyTask */
void vKeyTask(void const *argument)
{
    /* USER CODE BEGIN vKeyTask */
    uint8_t ucPC_flg = 0, ucKUKA_flg = 0; // pc,kuka开关机状态
    /* Infinite loop */
    for (;;)
    {
        osDelay(10);
        IOScan();  // IO口状态扫
        IOPress(); // IO口状态更

        if ((g_usIoStatus & 0x03) == 0x00) // pc按键按下
        {
            if (ucPC_flg == 0 && (g_usIoStatus & 0x30) == 0x30) // 未上电状态         
            {
                PC_ON;
                ucPC_flg = 1;
                LED_PcPwr_ON; // PC电源灯打开
            }
            else if (ucPC_flg == 2 && (g_usIoStatus & 0x30) == 0x00) // 上电状按下          
            {
                PC_OFF;
                ucPC_flg = 3;
                LED_PcPwr_OFF; // 关机
            }
        }
        else if (ucPC_flg == 1 && (g_usIoStatus & 0x30) == 0x00) // 上电完成
        {
            ucPC_flg = 2;
        }
        else if (ucPC_flg == 3 && (g_usIoStatus & 0x30) == 0x30) // 下电完成
        {
            ucPC_flg = 0;
        }
        

        if ((g_usIoStatus & 0x0c) == 0x00) // kuka按键按下
        {
            if (ucKUKA_flg == 0 ) // 未上电状态按下
            {
                KUKA_ON;
                ucKUKA_flg = 1;
                LED_KukaPwr_ON; // KUKA电源灯打开
            }        
            else if (ucKUKA_flg == 2 ) // 上电状按下
            {
                KUKA_OFF;
                ucKUKA_flg = 3;
                LED_KukaPwr_OFF; // 关机
            }
        }
        else if (ucKUKA_flg==1  && (g_usIoStatus & 0x0c) == 0x0c)
        {
            ucKUKA_flg=2;
        }  
        else if (ucKUKA_flg==3  && (g_usIoStatus & 0x0c) == 0x0c)
        {
            ucKUKA_flg=0;
        }       
    }
    /* USER CODE END vKeyTask */
}

/* USER CODE BEGIN Header_vCPU_Task */
/**
 * @brief Function implementing the CPU thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_vCPU_Task */
void vCPU_Task(void const *argument)
{
    /* USER CODE BEGIN vCPU_Task */
    uint8_t CPU_RunInfo[512];
    TickType_t xLastWakeTime = xTaskGetTickCount();
    TickType_t xPrediodicInterval = pdMS_TO_TICKS(2000);
    HAL_TIM_Base_Start_IT(&htim6); // 0.1ms 中断
    /* Infinite loop */
    for (;;)
    {
        // osDelay(2000);
        memset(CPU_RunInfo, 0, 512);
        vTaskList((char *)CPU_RunInfo);
        printf("/========================MCU Usage Statistics======================/\r\n");
        printf("Name                          |Sate   |Prio   |Stack  |Num\r\n");
        printf("%s\r\n", CPU_RunInfo);

        memset(CPU_RunInfo, 0, 512);
        vTaskGetRunTimeStats((char *)CPU_RunInfo);
        printf("Name                          |Time         |percentage\r\n");
        printf("%s\r\n", CPU_RunInfo);
        printf("/==============================================================/\r\n");
        printf("\r\n");
        vTaskDelayUntil(&xLastWakeTime, xPrediodicInterval);
    }
    /* USER CODE END vCPU_Task */
}

/* USER CODE BEGIN Header_vUsbControlTask */
/**
 * @brief Function implementing the UsbControl thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_vUsbControlTask */
void vUsbControlTask(void const *argument)
{
    /* USER CODE BEGIN vUsbControlTask */
    uint8_t ucFlag_UsbInit = 0;
    uint8_t ucCOM_Timer = 0;
    uint8_t ucaTxUpsSte[2];

    USB_Host_Init();
    CH375_InitSysVar();
    g_xUpsQueueHandle = xQueueCreate(1, sizeof(ucaTxUpsSte)); // 创建UPS状态消息队列
    /* Infinite loop */
    for (;;)
    {
        osDelay(1000);
        if (CH375_CheckConnect() == USBD_CONNECT) /* 刚检测到1个设备接 */
        {

            ucFlag_UsbInit = USB_init();

            if (ucFlag_UsbInit != 0)
                printf("USB_Fail! \r\n");
            else
                printf("USB_Successful! \r\n");
            ucFlag_UsbInit = 0;
            ucUps_one = 1; // 切换UPS主路模式
        }
        if (ucFlag_AllowSendCmd == 1) // 允许发UPS指令标志
        {
            ucFlag_AllowSendCmd = 0; // 清除允许发UPS指令标志
            CH375_Comm();            // UPS通讯入口主函函数
            ucaTxUpsSte[0] = ucUpsBatMode;
            ucaTxUpsSte[1] = ucUpsPwrMode;
            xQueueSend(g_xUpsQueueHandle, (const void *)ucaTxUpsSte, 0);
            ucCOM_Timer = 0;
        }
        if (++ucCOM_Timer > 4) // 通讯返回超时4次无应答
        {
            ucCOM_Timer = 0;
            if (++ucFlag_GetUpsState > 3)
                ucFlag_GetUpsState = 1;
            ucFlag_AllowSendCmd = 1; // 允许发UPS指令
            ucFlag_RxSuccece = 1;
        }
    }
    /* USER CODE END vUsbControlTask */
}

/* USER CODE BEGIN Header_vUartTask */
void vInspectAck(uint8_t *ucaNu1, uint8_t ucaNum)
{
    uint8_t ucaRsp[6];
    ucaRsp[0] = ucaNu1[0];
    ucaRsp[1] = ucaNu1[1];
    ucaRsp[2] = ucaNu1[2];
    ucaRsp[3] = ucaNum;
    ucaRsp[4] = ucaRsp[0] + ucaRsp[1] + ucaRsp[2] + ucaRsp[3];
    ucaRsp[5] = ucaNu1[5];
    HAL_UART_Transmit(&huart1, ucaRsp, 6, 10);
}

/**
 * @brief Function implementing the Uart thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_vUartTask */
void vUartTask(void const *argument)
{
    /* USER CODE BEGIN vUartTask */
    UBaseType_t uxNumberOfItems = 0;
    uint8_t ucaRxBuff[BUFFER_SIZE];
    uint8_t ucaRsp[6];
    uint8_t ucbuflen;
    uint8_t ucavison[16];
    g_xUart1QueueHandle = xQueueCreate(1, sizeof(ucaRxBuff));  // 创建串口1接收数据消息队列
    g_xUart1lenQueueHandle = xQueueCreate(1, sizeof(uint8_t)); // 创建串口1接收数据消息队列
    /* Infinite loop */
    for (;;)
    {
        osDelay(10);
        uxNumberOfItems = uxQueueMessagesWaiting(g_xUart1lenQueueHandle); // 查询队列中当前的项目
        if (uxNumberOfItems != 0)
        {
            xQueueReceive(g_xUart1QueueHandle, ucaRxBuff, 0);
            xQueueReceive(g_xUart1lenQueueHandle, &ucbuflen, 0);
            if (ucbuflen == 6)
            {
                if ((ucaRxBuff[0] + ucaRxBuff[1] + ucaRxBuff[2] + ucaRxBuff[3]) == ucaRxBuff[4])
                {
                    if (memcmp(ucaUartCommandTable[0], ucaRxBuff, 6) == 0)
                    {
                        DRILL_ON;
                        vInspectAck(ucaRxBuff, 0x11);
                    }
                    else if (memcmp(ucaUartCommandTable[1], ucaRxBuff, 6) == 0)
                    {
                        DRILL_OFF;
                        vInspectAck(ucaRxBuff, 0x11);
                    }
                    else if (memcmp(ucaUartCommandTable[10], ucaRxBuff, 6) == 0)
                    {
                        vInspectAck(ucaRxBuff, 0x11);
                    }
                    else
                    {
                        vInspectAck(ucaRxBuff, 0x00);
                    }
                }
            }
            else if (ucbuflen == 5)
            {
                if (memcmp(uuaPrivateCommandTable[0], ucaRxBuff, 5) == 0)
                {
                    printf("update...\r\n");
                    Jump_To_APP();
                }
                else if (memcmp(uuaPrivateCommandTable[1], ucaRxBuff, 5) == 0)
                {
                    printf("com_ok!\r\n");
                }
                else if (memcmp(uuaPrivateCommandTable[2], ucaRxBuff, 5) == 0)
                {
                    STMFLASH_Write(FLASH_SAVE_ADDR, (uint32_t *)ucaSoftVison, 4);
                    printf("%s\r\n", ucaSoftVison);
                }
                else if (memcmp(uuaPrivateCommandTable[3], ucaRxBuff, 5) == 0)
                {
                    STMFLASH_Read(FLASH_SAVE_ADDR, (uint32_t *)ucavison, 4);
                    printf("Vison:%s\r\n", ucavison);
                }             
            }
            uxNumberOfItems = 0;
            ucbuflen = 0;
            memset(ucaRxBuff, 0, sizeof(ucaRxBuff));
        }
    }
    /* USER CODE END vUartTask */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */
//////////////////////////////////////////////////////////////在线升级入口函数
void Jump_To_APP(void)
{
    uint32_t app_address = 0x1FFFF000;
    void (*pUserApp)(void);
    uint32_t JumpAddress;
    HAL_DMA_DeInit(&hdma_usart1_rx); // 需要关闭DMA
    HAL_DMA_DeInit(&hdma_usart1_tx);
    SysTick->CTRL = 0x00; // 禁止SysTick
    SysTick->LOAD = 0;
    SysTick->VAL = 0;
    __disable_irq(); // 禁止中断
    JumpAddress = *(volatile uint32_t *)(app_address + 4);
    pUserApp = (void (*)(void))JumpAddress;
    /* Initialize user application's Stack Pointer */
    __set_MSP(*(volatile uint32_t *)app_address);
    pUserApp();
}

void UART_IDLE_Callback(UART_HandleTypeDef *huart)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;

    if (__HAL_UART_GET_FLAG(&huart1, UART_FLAG_IDLE) != RESET)
    {
        __HAL_UART_CLEAR_IDLEFLAG(&huart1); // 清楚中断标志位
        uart1._rxend = 1;                   // 接收标志置1
        HAL_UART_DMAStop(&huart1);          // 关闭DMA
        /* get rx data len */
        uart1._rxlen = BUFFER_SIZE - __HAL_DMA_GET_COUNTER(&hdma_usart1_rx); // 计算接收数据长度
        //		printf("%s,%d\r\n",uart1._rxbufs,uart1._rxlen);
        if (uart1._rxlen <= 32)
        {
            xQueueSendFromISR(g_xUart1QueueHandle, (const void *)uart1._rxbufs, &xHigherPriorityTaskWoken); // 发送至队列
            xQueueSendFromISR(g_xUart1lenQueueHandle, (const void *)&uart1._rxlen, &xHigherPriorityTaskWoken);
            portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
        }
        uart1._rxlen = 0;
        uart1._rxend = 0;
        memset((void *)uart1._rxbufs, 0, BUFFER_SIZE); // 清buff

        HAL_UART_Receive_DMA(&huart1, uart1._rxbufs, BUFFER_SIZE); // 再次开启接收
    }
}

/* USER CODE END Application */
