#ifndef __SM16703_H_
#define __SM16703_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"

#define White  0xFFFFFF /* 白色 */
#define Black  0x000000 /* 无色 */
#define Red    0xFF0000 /* 红色 */
#define Green  0x00FF00 /* 绿色 */
#define Blue   0x0000FF /* 蓝色 */



#define nWs 120 /* 有多少颗SM16703级联 */

extern unsigned long WsDat[];


void WS_SetAll ( void );
void WS_Set1 ( unsigned long dat ); 
uint32_t ColorToColor ( unsigned long color0, unsigned long color1 );

#ifdef __cplusplus
}
#endif

#endif

