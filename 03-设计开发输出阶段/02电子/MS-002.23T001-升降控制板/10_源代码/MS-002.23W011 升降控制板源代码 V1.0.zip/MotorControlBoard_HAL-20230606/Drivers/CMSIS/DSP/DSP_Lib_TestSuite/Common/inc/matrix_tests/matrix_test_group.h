#ifndef _MATRIX_TEST_GROUP_H_
#define _MATRIX_TEST_GROUP_H_

/*--------------------------------------------------------------------------------*/
/* Declare Test Groups */
/*--------------------------------------------------------------------------------*/
JTEST_DECLARE_GROUP(matrix_tests);

#endif /* _MATRIX_TEST_GROUP_H_ */
